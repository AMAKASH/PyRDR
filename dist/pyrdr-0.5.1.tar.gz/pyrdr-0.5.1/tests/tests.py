from PyRDR import MCRDR, SCRDR

mckb = MCRDR([])
sckb = SCRDR([])
