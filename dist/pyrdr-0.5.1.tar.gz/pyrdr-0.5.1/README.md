# Package Description

This is a Ripple Down Rule Based Classifier Package. This Package used Rule Based Systems to do Single or Multi-class Classification.

More info coming soon.
